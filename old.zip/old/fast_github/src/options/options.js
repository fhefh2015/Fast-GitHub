import { config } from './config';
import "./css/bootstrap.min.css";
import "./css/options.css";

config();
